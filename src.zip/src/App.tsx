import UsersListTile from './components/UsersListTile'
import './App.css'
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div>
      <UsersListTile/>
    </div>
  )
}

export default App
